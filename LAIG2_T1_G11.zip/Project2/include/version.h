#ifndef version_h_
#define version_h_

const char CGFVersion[]= "v2.3";
const char CGFId[]= "$Id$";

#endif
