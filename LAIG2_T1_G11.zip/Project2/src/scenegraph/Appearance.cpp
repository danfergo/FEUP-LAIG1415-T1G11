#include "Appearance.h"



Appearance::Appearance(void)
{
}


Appearance::~Appearance(void)
{
}
